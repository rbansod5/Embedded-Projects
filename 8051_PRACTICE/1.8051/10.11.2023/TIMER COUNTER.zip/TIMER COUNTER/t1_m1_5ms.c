#include<reg51.h>
#include<intrins.h>

sbit led = P1^0;

//65536-5000=60536
//60536+15=60551 (0xEC87)

void timer1_mode1_5ms()
{
	TMOD = 0X10;
	TH1 = 0XEC;
	TL1 = 0X87;
	TR1 = 1;
	while(TF1==0);
	TF1 = 0;
	TR1 = 0;
	_nop_();
}

main()
{

	while(1)
	{
		led = ~led;
		timer1_mode1_5ms();
	
	}
	

}


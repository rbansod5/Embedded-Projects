#include<reg51.h>
#include<intrins.h>

sbit led = P1^0;

//256-250=6
//6+15=21 (0x15)

void timer1_mode2_250us()
{
	TMOD = 0X20;
	TH1 = 0x15;
	TL1 = 0X15;
	TR1 = 1;
	while(TF1==0);
	TF1 = 0;
	TR1 = 0;
	_nop_();
}

main()
{

	while(1)
	{
		led = ~led;
		timer1_mode2_250us();
	
	}
	

}


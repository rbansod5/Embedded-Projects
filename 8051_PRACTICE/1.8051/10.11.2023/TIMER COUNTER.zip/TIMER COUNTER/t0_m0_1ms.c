#include<reg51.h>
#include<intrins.h>

sbit led = P1^0;

//8192-1000=7192
//7192+15=7207 (1 1 1 0 0 0 0 1 0 0 1 1 1)
//5 BITS ARE LOADED INTO LOWER BYTE 8 BITS ARE LOADED INTO HIGHER BYTE
//MODE0 - 13 BIT MODE 

//MC - MACHINE CYCLE

void timer0_mode0_1ms()//FUNCTION CALL 2MC
{
	TMOD = 0X00;//2MC
	TH0 = 0XE1;//2MC
	TL0 = 0X07;//2MC
	TR0 = 1;//1MC
	while(TF0==0);//2MC
	TF0 = 0;//1MC
	TR0 = 0;//1MC
	_nop_();
}//RETURN-2MC

main()
{

	while(1)
	{
		led = ~led;
		timer0_mode0_1ms();	
	}
	

}


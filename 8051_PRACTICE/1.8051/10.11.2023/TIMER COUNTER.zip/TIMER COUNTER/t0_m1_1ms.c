#include<reg51.h>
#include<intrins.h>

sbit led = P1^0;
//65536-1000=64536
//64536+15=64551 (0xFC27)

/*
TIMER0 MODE1 SELECTION
TMOD REGISTER:
GATE C/T M1 M0 GATE C/T M1 M0
  0   0  0  0   0    0  0   1 = 0X01
*/
void timer0_mode1_1ms()
{
	TMOD = 0X01;
	TH0 = 0XFC;
	TL0 = 0X27;
	TR0 = 1;
	while(TF0==0);
	TF0 = 0;
	TR0 = 0;
	_nop_();
}

main()
{

	while(1)
	{
		led = ~led;
		timer0_mode1_1ms();
	
	}
	

}


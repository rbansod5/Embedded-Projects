#include<reg51.h>
#include<intrins.h>

sbit led = P1^0;

//65536-1000=64536
//64536+15=64551 (0xFC27)

/*
TIMER1 MODE1 SELECTION
TMOD REGISTER:
     TIMER1   |   TIMER0
----------------------------
GATE C/T M1 M0 GATE C/T M1 M0
  0   0  0  1   0    0  0   0 = 0X10
*/

void timer1_mode1_1ms()
{
	TMOD = 0X10;
	TH1 = 0XFC;
	TL1 = 0X27;
	TR1 = 1;
	while(TF1==0);
	TF1 = 0;
	TR1 = 0;
	_nop_();
}

main()
{

	while(1)
	{
		led = ~led;
		timer1_mode1_1ms();
	
	}
	

}


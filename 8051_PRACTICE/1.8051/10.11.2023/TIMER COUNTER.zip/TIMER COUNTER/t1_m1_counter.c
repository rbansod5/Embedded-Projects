#include<reg51.h>





main()
{
	unsigned char cnt=0;

	TMOD = 0x50;	//timer0,mode1 as counter
	TH1 = 0x00;
	TL1 = 0x00;
	TR1 = 1;
	while(1)
	{
	
		cnt = (TH1*256) + TL1;	
	
		P0 = cnt;
	
	}
	

}


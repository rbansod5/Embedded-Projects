#include<reg51.h>
#include<intrins.h>

sbit led = P1^0;

//8192-1000=7192
//7192+15=7207 (1 1 1 0 0 0 0 1 0 0 1 1 1)

void timer1_mode0_1ms()
{
	TMOD = 0X00;
	TH1 = 0XE1;
	TL1 = 0X07;
	TR1 = 1;
	while(TF1==0);
	TF1 = 0;
	TR1 = 0;
	_nop_();
}

main()
{

	while(1)
	{
		led = ~led;
		timer1_mode0_1ms();
	
	}
	

}


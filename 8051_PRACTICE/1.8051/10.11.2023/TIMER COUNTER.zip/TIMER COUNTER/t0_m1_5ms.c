#include<reg51.h>
#include<intrins.h>

sbit led = P1^0;

//65536-5000=60536
//60536+15=60551 (0xEC87)

void timer0_mode1_5ms()
{
	TMOD = 0X01;
	TH0 = 0XEC;
	TL0 = 0X87;
	TR0 = 1;
	while(TF0==0);
	TF0 = 0;
	TR0 = 0;
	_nop_();
}

main()
{

	while(1)
	{
		led = ~led;
		timer0_mode1_5ms();
	
	}
	

}


#include<reg51.h>





main()
{
	unsigned char cnt=0;

	TMOD = 0x05;	//timer0,mode1 as counter
	TH0 = 0x00;
	TL0 = 0x00;
	TR0 = 1;
	while(1)
	{
	
		cnt = (TH0*256) + TL0;	
	
		P0 = cnt;
	
	}
	

}


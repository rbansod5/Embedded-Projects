#include<reg51.h>
#include<intrins.h>

sbit led = P1^0;

//8192-500=7692
//7692+15=7707 (1 1 1 1 0 0 0 0 1 1 0 1 1)

void timer0_mode0_500us()
{
	TMOD = 0X00;
	TH0 = 0XF0;
	TL0 = 0X1B;
	TR0 = 1;
	while(TF0==0);
	TF0 = 0;
	TR0 = 0;
	_nop_();
}

main()
{

	while(1)
	{
		led = ~led;
		timer0_mode0_500us();
	
	}
	

}


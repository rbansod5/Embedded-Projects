#include<reg51.h>
#include<intrins.h>

sbit led = P1^0;

//256-250=6
//6+13=19 (0x13)

/*
TIMER0 MODE3 SELECTION
TMOD REGISTER:
GATE C/T M1 M0 GATE C/T M1 M0
  0   0  0  0   0    0  1   1 = 0X03
*/

void timer0_mode3_1ms()
{
	TMOD = 0X03;
	//TH0 = xx;
	TL0 = 0X13;
	TR0 = 1;
	while(TF0==0);
	TF0 = 0;
	TR0 = 0;
	_nop_();
}

main()
{

	while(1)
	{
		led = ~led;
		timer0_mode3_1ms();
	
	}
	

}


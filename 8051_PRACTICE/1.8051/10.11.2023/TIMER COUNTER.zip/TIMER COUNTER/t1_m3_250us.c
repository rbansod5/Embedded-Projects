#include<reg51.h>
#include<intrins.h>

sbit led = P1^0;

//256-250=6
//6+13=19 (0x13)

void timer1_mode3_1ms()
{
	TMOD = 0X33;
	TH0 = 0x13;
	//TL0 = 0X13;
	TR1 = 1;
	while(TF1==0);
	TF1 = 0;
	TR1 = 0;
	_nop_();
}

main()
{

	while(1)
	{
		led = ~led;
		timer1_mode3_1ms();
	
	}
	

}


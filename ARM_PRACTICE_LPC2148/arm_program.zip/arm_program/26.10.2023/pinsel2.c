#include <LPC21xx.H>

#include "pin_function_defines.h"

int main()
{
	PINSEL0 = 0x00000000;
	PINSEL0 = 0x00000001;
	PINSEL0 = 0x00000002;
	PINSEL0 = 0x00000003;
	
	PINSEL0 |= 0x00000000;
	PINSEL0 |= 0x00000001;
	PINSEL0 |= 0x00000002;
	PINSEL0 |= 0x00000003;
	
	PINSEL0 |= 2<<0;//p0.0-func3
	PINSEL0 |= 2<<2;//p0.1-func3
	PINSEL0 |= 2<<4;//p0.2-func3
	PINSEL0 |= 1<<6;//p0.3-func2
	PINSEL0 |= 2<<6;//p0.3-func3
	
	PINSEL0 |= FUNC3<<0;//p0.0-func3
	PINSEL0 |= FUNC3<<2;//p0.1-func3
	PINSEL0 |= FUNC3<<4;//p0.2-func3
	
	CFGPIN(PINSEL0,2,FUNC1);
	CFGPIN(PINSEL0,7,FUNC3);
	CFGPIN(PINSEL0,14,FUNC3);
	
	CFGPIN(PINSEL1,16,FUNC3);


	while(1);
}
